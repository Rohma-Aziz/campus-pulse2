from flask import Blueprint, render_template, request, redirect, url_for, flash, g
from app import db
from app.models import Feedback, DEPARTMENTS, CATEGORIES

feedback_bp = Blueprint("feedback", __name__, url_prefix="/feedback")

@feedback_bp.route("/dashboard")
def dashboard():
    if not g.user or g.user.is_admin:
        flash("Please log in as a student to access your dashboard.", "danger")
        return redirect(url_for("auth.login"))
    return render_template("student_dashboard.html")

@feedback_bp.route("/submit", methods=["GET", "POST"])
def submit():
    if not g.user or g.user.is_admin:
        return redirect(url_for("auth.login"))
    
    if request.method == "POST":
        title = request.form.get("title")
        category = request.form.get("category")
        description = request.form.get("description")
        rating = request.form.get("rating", type=int)
        is_anonymous = bool(request.form.get("anonymous"))

        if not title or not category or not description or not rating:
            flash("Please fill in all required fields.", "danger")
            return redirect(url_for("feedback.submit"))

        feedback = Feedback(
            user_id=g.user.id,
            title=title,
            category=category,
            description=description,
            rating=rating,
            is_anonymous=is_anonymous,
            status="Pending"
        )
        db.session.add(feedback)
        db.session.commit()
        
        flash("Feedback submitted successfully!", "success")
        return redirect(url_for("feedback.success", sub_id=feedback.id))

    return render_template("submit_feedback.html", categories=CATEGORIES)

@feedback_bp.route("/success/<int:sub_id>")
def success(sub_id):
    if not g.user:
        return redirect(url_for("auth.login"))
    feedback = Feedback.query.get_or_404(sub_id)
    return render_template("success.html", feedback=feedback)

@feedback_bp.route("/submissions")
def my_submissions():
    if not g.user or g.user.is_admin:
        return redirect(url_for("auth.login"))
    submissions = Feedback.query.filter_by(user_id=g.user.id).all()
    return render_template("my_submissions.html", submissions=submissions)


