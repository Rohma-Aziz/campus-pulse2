from flask import Blueprint, flash, redirect, render_template, url_for
from sqlalchemy import func, select

from app import db
from app.models import Post, Report
from app.utils import admin_required
from flask import Blueprint, render_template, request, redirect, url_for, flash, g
from app import db
from app.models import Feedback, User

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route('/moderation', methods=['GET'])
@admin_required
def moderation_queue():
    # Fetch posts/feedback that are reported, flagged, or hidden pending review
    # Aapke model ke field names ke mutabiq filter adjust kar sakte hain (e.g. is_flagged or reports > 0)
    flagged_items = Feedback.query.filter((Feedback.is_flagged == True) | (Feedback.reports > 0)).all()
    return render_template('moderation.html', flagged_items=flagged_items)

@admin_bp.route('/moderation/approve/<int:item_id>', methods=['POST'])
@admin_required
def approve_content(item_id):
    item = Feedback.query.get_or_404(item_id)
    item.is_flagged = False
    item.reports = 0
    item.is_hidden = False
    db.session.commit()
    flash("Content approved and made visible on feed.", "success")
    return redirect(url_for('admin.moderation_queue'))

@admin_bp.route('/moderation/remove/<int:item_id>', methods=['POST'])
@admin_required
def remove_content(item_id):
    item = Feedback.query.get_or_404(item_id)
    item.is_hidden = True
    db.session.commit()
    flash("Content hidden/removed successfully.", "info")
    return redirect(url_for('admin.moderation_queue'))

@admin_bp.route("/dashboard")
def dashboard():
    if not g.user or not g.user.is_admin:
        flash("Unauthorized access.", "danger")
        return redirect(url_for("auth.login"))
    return render_template("admin_dashboard.html")

@admin_bp.route('/manage-issues', methods=['GET'])
@admin_required
def manage_issues():
    status_filter = request.args.get('status', '')
    category_filter = request.args.get('category', '')
    dept_filter = request.args.get('department', '')

    query = Feedback.query
    if status_filter:
        query = query.filter_by(status=status_filter)
    if category_filter:
        query = query.filter_by(category=category_filter)
    if dept_filter:
        query = query.filter_by(department=dept_filter)

    items = query.order_by(Feedback.created_at.desc()).all()

    # Status counts for top summary cards
    statuses = ['Pending', 'In Progress', 'Resolved']
    counts = {s: Feedback.query.filter_by(status=s).count() for s in statuses}
    
    categories = db.session.query(Feedback.category.distinct()).all()
    categories = [c[0] for c in categories if c[0]]
    
    departments = db.session.query(Feedback.department.distinct()).all()
    departments = [d[0] for d in departments if d[0]]

    return render_template(
        'manage_issues.html',
        items=items,
        statuses=statuses,
        counts=counts,
        categories=categories,
        departments=departments,
        status=status_filter,
        category=category_filter,
        department=dept_filter,
        pagination=None
    )

@admin_bp.route('/update-issue/<int:feedback_id>', methods=['POST'])
@admin_required
def update_issue(feedback_id):
    item = Feedback.query.get_or_404(feedback_id)
    new_status = request.form.get('status')
    admin_note = request.form.get('admin_note')

    if new_status:
        item.status = new_status
    if admin_note is not None:
        item.admin_note = admin_note

    db.session.commit()
    flash(f"Issue CP-{item.id:04d} updated successfully!", "success")
    return redirect(url_for('admin.manage_issues', 
                            status=request.form.get('status_filter'),
                            category=request.form.get('category_filter'),
                            department=request.form.get('department_filter')))