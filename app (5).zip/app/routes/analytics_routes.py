from flask import Blueprint, render_template, redirect, url_for, flash, g
from app.analytics import process_analytics, generate_insights, get_chart_data
import pandas as pd
import os

analytics_bp = Blueprint('analytics', __name__, template_folder='../templates')

@analytics_bp.route('/analytics')
def analytics_dashboard():
    if not g.get('user'):
        flash("Please log in to view analytics.", "warning")
        return redirect(url_for("auth.login"))

    # File path check karein taaki FileNotFoundError na aaye
    csv_path = 'sample_feedback.csv'
    if not os.path.exists(csv_path):
        flash("Analytics data file not found.", "danger")
        return redirect(url_for('feedback.dashboard'))

    df = pd.read_csv(csv_path)
    
    # Safe data fetching with fallback empty dictionaries/lists
    metrics = process_analytics(df) if process_analytics else {}
    insights = generate_insights(df) if generate_insights else []
    chart_data = get_chart_data(df) if get_chart_data else {}
    
    return render_template(
        'analytics.html', 
        metrics=metrics or {}, 
        insights=insights or [],
        chart_data=chart_data or {}
    )